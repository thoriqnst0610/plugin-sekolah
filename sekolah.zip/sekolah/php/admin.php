<?php

/**
 * Function menampilkan menu
 * Hook: admin_menu
 */

add_action('admin_menu', 'menusekolah');
function menusekolah()
{
    add_menu_page(
        'WP SEKOLAH',
        'Wp Sekolah',
        'manage_options',
        'menampilkan_alumni',
        'sekolah_callback',
        'dashicons-welcome-learn-more',
    );

    add_submenu_page(
        'submenu', //Parent Slug
        'mengubah alumni', //Page Title
        'tidak terlihat', //Menu Title
        'manage_options', //Capability
        'mengedit_alumni', //Slug URL
        'sekolah_callback' //Callback
    );

    add_submenu_page(
        'submenu', //Parent Slug
        'mengekspor alumni', //Page Title
        'tidak terlihat', //Menu Title
        'manage_options', //Capability
        'mengekspor_alumni', //Slug URL
        'sekolah_callback' //Callback
    );


    add_submenu_page(
        'menampilkan_alumni',
        'Wp Siswa',
        'calon siswa',
        'manage_options',
        'tampil_siswa',
        'siswa_callback'
    );

    add_submenu_page(
        'submenu',
        'download file',
        'download file',
        'manage_options',
        'download file',
        'siswa_callback'
    );

    add_submenu_page(
        'menampilkan_alumni',
        'pengaturan',
        'pengaturan',
        'manage_options',
        'pengaturan',
        'pengaturan_callback'
    );

    add_submenu_page(
        'd',
        'pengaturan',
        'pengaturan',
        'manage_options',
        'download gambar',
        'sekola_callback'
    );
}

function sekolah_callback()
{

    $page = isset($_GET['page']) ? $_GET['page'] : '';

    if ($page == "menambah_alumni") {

        include __DIR__ . '/crudAlumni/menambah.php';
    } else if ($page == "mengedit_alumni") {

        include_once plugin_dir_path(__FILE__) . 'function.php';
        include __DIR__ . '/crudAlumni/mengedit.php';
        include ADMINSEKOLAH_DIR . 'ubah-alumni.php';
    } else if ($page == "menghapus_alumni") {

        include __DIR__ . '/crudAlumni/menghapus.php';
    } else if ($page == "menampilkan_alumni") {

        $aksi = isset($_POST['aksi']) ? $_POST['aksi'] : '';

        if ($aksi == 'hapus') {

            $id_alumni = isset($_POST['id_alumni']) ? $_POST['id_alumni'] : '';
            include_once plugin_dir_path(__FILE__) . 'crudAlumni/menghapus.php';
        } else {

            include_once plugin_dir_path(__FILE__) . 'function.php';
            include_once plugin_dir_path(__FILE__) . 'crudAlumni/menambah.php';
        }

        include ADMINSEKOLAH_DIR . 'daftar-alumni.php';
    } else if ($page == "mengekspor_alumni") {
        include ADMINSEKOLAH_DIR . 'ekspor-alumni.php';
    } else {

        include ADMINSEKOLAH_DIR . 'notfound.php';
    }
}

function siswa_callback()
{

    $page = isset($_GET['page']) ? $_GET['page'] : '';



    if ($page == "download file") {

        include ADMINSEKOLAH_DIR . 'download_pdf.php';
    }

    $aksi = isset($_POST['aksi']) ? $_POST['aksi'] : '';
    if ($aksi == 'hapus') {

        $id_calon = isset($_POST['id_calon']) ? $_POST['id_calon'] : '';
        include __DIR__ . '/crudSiswa/menghapus_siswa.php';
    } else if ($aksi == 'hapus_keseluruhan') {
        include __DIR__ . '/crudSiswa/hapus_seluruh_siswa.php';
    }

    include ADMINSEKOLAH_DIR . 'daftar-siswa.php';
}

function pengaturan_callback()
{

   
    if($_SERVER['REQUEST_METHOD'] == "POST"){
        include __DIR__. '/pengaturan/ubah.php';
    }
    include ADMINSEKOLAH_DIR . 'pengaturan.php';

}