<?php

function menambahAlumni()
{

    $id_alumni = uuid();
    // Mengambil dan membersihkan data
    $nama_alumni = isset($_POST['nama_alumni']) ? sanitize_text_field($_POST['nama_alumni']) : '';
    $alamat = isset($_POST['alamat']) ? sanitize_textarea_field($_POST['alamat']) : ''; // Jika input adalah textarea
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? sanitize_text_field($_POST['jenis_kelamin']) : '';
    $jurusan = isset($_POST['jurusan']) ? sanitize_text_field($_POST['jurusan']) : '';
    $telepon = isset($_POST['telepon']) ? sanitize_text_field($_POST['telepon']) : '';
    $cita_cita = isset($_POST['cita_cita']) ? sanitize_text_field($_POST['cita_cita']) : '';
    $tahun_lulus = isset($_POST['tahun_lulus']) ? sanitize_text_field($_POST['tahun_lulus']) : '';

    if (!empty($nama_alumni) && !empty($alamat) && !empty($jurusan) && !empty($telepon) || !empty($cita_cita) || !empty($tahun_lulus) || isset($_FILES["photo"])) {

        try {
            if (!isset($_POST['alumnitambah_nonce']) || !wp_verify_nonce($_POST['alumnitambah_nonce'], 'alumnitambah_nonce_action')) {
                throw new Exception("maaf token csrf tidak sesuai");
            }
            $gambarAlumni = gambarAlumni($_FILES["photo"]);

            if (is_wp_error($gambarAlumni)) {
                throw new Exception($gambarAlumni->get_error_message());
            }

            $alumni = [
                'id_alumni' => $id_alumni,
                'nama_alumni' => $nama_alumni,
                'jurusan' => $jurusan,
                'jenis_kelamin' => $jenis_kelamin,
                'alamat' => $alamat,
                'foto_alumni' => $gambarAlumni,
                'telepon' => $telepon,
                'cita_cita' => $cita_cita,
                'tahun_lulus' => $tahun_lulus
            ];

            $tambahAlumni = tambahAlumni('alumni_siswa', $alumni);
            if ($tambahAlumni) {

                return $notifikasi = "berhasil menambah alumni baru";
            }
        } catch (Exception $e) {

            return $notifikasi = "ada kesalahan" . addslashes($e->getMessage());
        }
    } else {
        return $notifikasi = "selamat datang";
    }
}

$notifikasi =  menambahAlumni();
