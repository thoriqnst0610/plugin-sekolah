<?php

function menghapusAlumni(string $id_alumni)
{

    $where = array('id_alumni' => $id_alumni);
    $hapusData = hapusAlumni('alumni_siswa', $where);
}

menghapusAlumni($id_alumni);