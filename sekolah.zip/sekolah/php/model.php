<?php

function ambilAlumni($nama_table)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $sql = "SELECT * FROM " . $table_name;
    $query = $wpdb->get_results($sql);
    return $query;
}

function ambilAlumniId($nama_table, $id_alumni)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_alumni = %s", $id_alumni);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function tambahAlumni($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $wpdb->insert($table_name, $data);
    $id_insert = $wpdb->insert_id;
    return $id_insert;
}

function editAlumni($nama_table, $data = array(), $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $update = $wpdb->update($table_name, $data, $where);
    return $update;
}

function tampilAlumniId($nama_table, $id_alumni)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_alumni = %s", $id_alumni);
    $query = $wpdb->get_row($sql);
    return $query;
}

function hapusAlumni($nama_table, $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $delete = $wpdb->delete($table_name, $where);
    return $delete;
}




//alumni

function tambahSiswa($nama_table, $data = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Cek apakah insert berhasil
    $inserted = $wpdb->insert($table_name, $data);
    
    if ($inserted === false) {
        return new WP_Error('insert_failed', 'Gagal menambahkan data siswa.');
    }
    
    // Mengembalikan ID dari baris yang baru ditambahkan
    return $wpdb->insert_id;
}

function ambilSiswa($nama_table)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $sql = "SELECT * FROM " . $table_name;
    $query = $wpdb->get_results($sql);
    return $query;
}

function hapuSiswa($nama_table, $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $delete = $wpdb->delete($table_name, $where);
    return $delete;
}

function hapusSemuaSiswa($nama_table) {
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $wpdb->query("TRUNCATE TABLE $table_name");
}

function ambilSiswaId($nama_table, $id_calon)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_calon = %s", $id_calon);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function ambilSiswaTelp($nama_table, $telepon)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE telepon = %s", $telepon);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function ambilDokumen($nama_table, $dokumen)
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE dokumen_lainnya = %s", $dokumen);
    $query = $wpdb->get_row($sql);
    
    return $query;
}

function ambilPengaturan($nama_table, $pengaturan)
{

    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;

    // Gunakan prepare untuk menghindari SQL injection
    $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id_pengaturan = %s", $pengaturan);
    $query = $wpdb->get_row($sql);
    
    return $query;

}

function editPengaturan($nama_table, $data = array(), $where = array())
{
    global $wpdb;
    $table_name = $wpdb->prefix . $nama_table;
    $update = $wpdb->update($table_name, $data, $where);
    return $update;
}