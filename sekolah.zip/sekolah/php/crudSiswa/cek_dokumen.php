<?php

function cekDokumen(string $nama_dokumen){

    $ambil_dokumen = ambilDokumen('calon_siswa', $nama_dokumen);
    if($ambil_dokumen){

        return $ambil_dokumen->dokumen_lainnya;
    }else{
        return false;
    }
}