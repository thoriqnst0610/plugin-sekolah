<?php

function hapusSemua()
{

    hapusSemuaSiswa("calon_siswa");
}

hapusSemua();