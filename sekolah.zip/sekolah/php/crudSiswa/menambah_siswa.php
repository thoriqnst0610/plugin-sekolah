<?php

require_once __DIR__ . '/../function.php';

function menambahSiswa()
{

    $id_calon = uuid();
    // Mengambil dan membersihkan data
    $nama_calon = isset($_POST['nama_calon']) ? sanitize_text_field($_POST['nama_calon']) : '';
    $alamat_calon = isset($_POST['alamat_calon']) ? sanitize_textarea_field($_POST['alamat_calon']) : ''; // Jika menggunakan textarea
    $alumni_calon = isset($_POST['alumni_calon']) ? sanitize_text_field($_POST['alumni_calon']) : '';
    $telepon = isset($_POST['telepon']) ? sanitize_text_field($_POST['telepon']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : ''; // Gunakan sanitize_email untuk email
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? sanitize_text_field($_POST['jenis_kelamin']) : '';

    $data_siswa = ambilSiswaTelp('calon_siswa', $telepon);

    if ($data_siswa == null) {

        if (!empty($nama_calon) && !empty($alamat_calon) && !empty($alumni_calon) && !empty($telepon) || !empty($email) || isset($_FILES["dokumen_lainnya"]) || isset($_FILES["pasphoto"])) {

            try {

                $pasphoto = pasPhoto($_FILES["pasphoto"]);
                $dokeman_lainnya = dokumenLainnya($_FILES["dokumen_lainnya"]);

                if (is_wp_error($pasphoto)) {
                    throw new Exception($pasphoto->get_error_message());
                }

                if (is_wp_error($dokeman_lainnya)) {
                    throw new Exception($dokeman_lainnya->get_error_message());
                }

                $data = [
                    'id_calon' => $id_calon,
                    'nama_calon' => $nama_calon,
                    'alamat_calon' => $alamat_calon,
                    'alumni_calon' => $alumni_calon,
                    'telepon' => $telepon,
                    'email' => $email,
                    'jenis_kelamin' => $jenis_kelamin,
                    'pasphoto' => $pasphoto,
                    'dokumen_lainnya' => $dokeman_lainnya
                ];

                $id_baru = tambahSiswa('calon_siswa', $data);

                if (is_wp_error($id_baru)) {
                    throw new Exception("Error: " . $id_baru->get_error_message());
                } else {
                    return "Selamat Berhasil Melakukan Registrasi, cetak Kartu Pendaftaran Sekarang";
                }
            } catch (Exception $e) {

                return "ada kesalahan dalam file yang di upload, lakukan pendaftaran Lagi!" . addslashes($e->getMessage());
            }
        } else {

            return "data yang diinput tidak lengkap, lakukan pendaftaran Lagi!";
        }
    } else {

        return "Maaf Anda Sudah Mendaftarkan Nomor Telepon Tersebut";
    }
}
