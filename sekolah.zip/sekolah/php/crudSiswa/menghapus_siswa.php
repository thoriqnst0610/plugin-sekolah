<?php

function menghapuSiswa(string $id_calon)
{

    $where = array('id_calon' => $id_calon);
    $hapusData = hapuSiswa('calon_siswa', $where);
}

menghapuSiswa($id_calon);