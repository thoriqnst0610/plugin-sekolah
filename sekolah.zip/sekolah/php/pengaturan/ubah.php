<?php
 // Mengambil dan membersihkan data
 $nama_sekolah = isset($_POST['nama_sekolah']) ? sanitize_text_field($_POST['nama_sekolah']) : '';
 $pengumuman = isset($_POST['pengumuman']) ? sanitize_textarea_field($_POST['pengumuman']) : ''; // Jika menggunakan textarea
 $url_cetak = isset($_POST['url_cetak']) ? esc_url_raw($_POST['url_cetak']) : ''; // Sanitasi URL
 $url_pengumuman = isset($_POST['url_pengumuman']) ? esc_url_raw($_POST['url_pengumuman']) : ''; // Sanitasi URL
 $url_gambar_pdf = isset($_POST['url_gambar_pdf']) ? esc_url_raw($_POST['url_gambar_pdf']) : ''; // Sanitasi URL
   
        if (!empty($nama_sekolah) && !empty($pengumuman) && !empty($url_pengumuman) && !empty($url_cetak)) {
            $data = array(
                'nama_sekolah' => $nama_sekolah,
                'pengumuman' => $pengumuman,
                'url_cetak' => $url_cetak,
                'url_pengumuman' => $url_pengumuman,
                'url_gambar_pdf' => $url_gambar_pdf
            );
            // Mulai-Ubah data
            $where = array('id_pengaturan' => '12345');
            $ubahData = editPengaturan('pengaturan', $data, $where);
            if ($ubahData) {
                $notifikasi = "berhasil mengubah pengaturan";
            } else {
                $notifikasi = "tidak ada perubahan";
            }
            // Selesai-Ubah data
        }

        ?>