<?php

add_shortcode('pendaftaran', 'pendaftaran');
function pendaftaran()
{
    if (!session_id()) {
        session_start();
    }

    ob_start();
    if ($_SERVER['REQUEST_METHOD'] == "POST") {

        if (!isset($_SESSION['pendaftaran_berhasil'])) {

            if (!isset($_POST['pendaftaran_nonce']) || !wp_verify_nonce($_POST['pendaftaran_nonce'], 'pendaftaran_nonce_action')) {
                $pesan = "Maaf, Token Csrf Tidak Sesuai! anda harus mendaftar dari sumber yang sah";
            } else {
                require_once __DIR__ . '/crudSiswa/menambah_siswa.php';
                $_SESSION['pendaftaran_berhasil'] = true;

                $pesan = menambahSiswa();
            }
        } else {

            require_once __DIR__ . '/crudSiswa/menambah_siswa.php';
            $pesan = menambahSiswa();
        }
    }
    include LANDINGSEKOLAH_DIR . 'pendaftaran.php';
    return ob_get_clean();
}

add_shortcode('daftar-alumni', 'daftar_alumni');
function daftar_alumni()
{
    ob_start();

    include LANDINGSEKOLAH_DIR . 'menampilkan-alumni.php';

    return ob_get_clean();
}


add_shortcode('tampilpdf', 'tampilpdf');
function tampilpdf() {}

add_action('init', 'generate_pdf_shortcode');
function generate_pdf_shortcode()
{

    if(current_user_can('administrator')){
        if (isset($_GET['generate_pdf'])) {

            if ($_GET['generate_pdf'] == "calon_siswa") {
    
                include LANDINGSEKOLAH_DIR . 'ekspor-siswa.php';
            } else if ($_GET['generate_pdf'] == 'alumni_siswa') {
    
                include LANDINGSEKOLAH_DIR . 'ekspor-alumni.php';
            }
        }else if(isset($_GET['dokumen'])){

            require __DIR__. '/../views/admin/ambil_dokumen.php';
            include LANDINGSEKOLAH_DIR . 'cek_pdf.php';
            
        }else if(isset($_GET['pasphoto'])){
            
            include LANDINGSEKOLAH_DIR . 'cek_gambar.php';
            
        }else {
    
            if (isset($_POST['nomor_telepon'])) {
                include LANDINGSEKOLAH_DIR . 'cetak-kartu-siswa.php';
            }
        }

    }else{
        //echo"<h1>maaf anda bukan administrator</h1>";
    }
    
}

add_shortcode('form-cetak-kartu', 'cetak_kartu');
function cetak_kartu()
{
    ob_start();
    if (isset($_POST['nomor_telepon'])) {
        generate_pdf_shortcode();
    }
    include LANDINGSEKOLAH_DIR . 'form-cetak.php';
    return ob_get_clean();
}
