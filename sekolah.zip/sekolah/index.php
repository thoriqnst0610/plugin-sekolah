<?php

/**
 * Plugin Name: WP Sekolah
 * Description: WP Sekolah adalah plugin manajemen data pendaftaran siswa dan manajemen alumni siswa
 * Author: Thoriq
 * Author URI: https://nastiweb.my.id
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

// Act on plugin activation
register_activation_hook(__FILE__, "activate_wp_sekolah");
function activate_wp_sekolah()
{
    init_db_alumni();
    init_db_calon();
    init_db_pengaturan();
    insert_pengaturan("12345","Smk 2 Panyabungan","informasi tambahan","http://localhost/custom/cetakartu/","http://localhost/custom/","http://localhost/custom/");
}

function init_db_alumni()
{

    global $table_prefix, $wpdb;
    $alumniTable = $table_prefix . 'alumni_siswa';

    // Create Alumni Table if not exist
    if ($wpdb->get_var("show tables like '$alumniTable'") != $alumniTable) {
        // Query - Create Table
        $sql = "CREATE TABLE `$alumniTable` (";
        $sql .= " `id_alumni` varchar(35) NOT NULL, ";
        $sql .= " `nama_alumni` varchar(100) NOT NULL, ";
        $sql .= " `jurusan` varchar(100) NOT NULL, ";
        $sql .= " `jenis_kelamin` varchar(100) NOT NULL, ";
        $sql .= " `alamat` varchar(255), ";
        $sql .= " `foto_alumni` varchar(255), ";
        $sql .= " `telepon` varchar(15), ";
        $sql .= " `cita_cita` varchar(100), ";
        $sql .= " `tahun_lulus` varchar(100), ";
        $sql .= " PRIMARY KEY (`id_alumni`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1;";

        // Include Upgrade Script
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        // Create Table
        dbDelta($sql);
    }

}

function init_db_calon()
{
    global $table_prefix, $wpdb;
    $calonSiswaTable = $table_prefix . 'calon_siswa';

    // Create Calon Siswa Table if not exist
    if ($wpdb->get_var("show tables like '$calonSiswaTable'") != $calonSiswaTable) {
        // Query - Create Table
        $sql = "CREATE TABLE `$calonSiswaTable` (";
        $sql .= " `id_calon` varchar(35) NOT NULL, ";
        $sql .= " `nama_calon` varchar(100) NOT NULL, ";
        $sql .= " `alamat_calon` varchar(255), ";
        $sql .= " `alumni_calon` varchar(100), ";
        $sql .= " `telepon` varchar(15), ";
        $sql .= " `email` varchar(100), ";
        $sql .= " `jenis_kelamin` varchar(10), ";
        $sql .= " `pasphoto` varchar(255), ";
        $sql .= " `dokumen_lainnya` varchar(255), ";
        $sql .= " PRIMARY KEY (`id_calon`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1;";

        // Include Upgrade Script
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        // Create Table
        dbDelta($sql);
    }
}

function init_db_pengaturan()
{
    global $table_prefix, $wpdb;
$pengaturanTable = $table_prefix . 'pengaturan';

// Create Pengaturan Table if not exist
if ($wpdb->get_var("SHOW TABLES LIKE '$pengaturanTable'") != $pengaturanTable) {
    // Query - Create Table
    $sql = "CREATE TABLE `$pengaturanTable` (";
    $sql .= " `id_pengaturan` varchar(35) NOT NULL, ";
    $sql .= " `nama_sekolah` text DEFAULT NULL, ";
    $sql .= " `pengumuman` text DEFAULT NULL, ";
    $sql .= " `url_cetak` varchar(200) DEFAULT NULL, ";
    $sql .= " `url_pengumuman` varchar(200) DEFAULT NULL, ";
    $sql .= " `url_gambar_pdf` varchar(150) NOT NULL, ";
    $sql .= " PRIMARY KEY (`id_pengaturan`) ";
    $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";

    // Include Upgrade Script
    require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
    // Create Table
    dbDelta($sql);
}

function insert_pengaturan($id_pengaturan, $nama_sekolah, $pengumuman, $url_cetak, $url_pengumuman, $url_gambar_pdf) {
    global $wpdb;
    $pengaturanTable = $wpdb->prefix . 'pengaturan'; // Menggunakan prefix tabel yang benar

    // Data yang akan dimasukkan
    $data = array(
        'id_pengaturan'    => $id_pengaturan,
        'nama_sekolah'     => $nama_sekolah,
        'pengumuman'       => $pengumuman,
        'url_cetak'        => $url_cetak,
        'url_pengumuman'   => $url_pengumuman,
        'url_gambar_pdf'   => $url_gambar_pdf,
    );

    // Format data sesuai tipe kolom di database
    $format = array(
        '%s', // id_pengaturan
        '%s', // nama_sekolah
        '%s', // pengumuman
        '%s', // url_cetak
        '%s', // url_pengumuman
        '%s', // url_gambar_pdf
    );

    // Melakukan insert
    $inserted = $wpdb->insert($pengaturanTable, $data, $format);

    // Cek apakah insert berhasil
    if ($inserted === false) {
        return "Insert failed: " . $wpdb->last_error;
    } else {
        return "Insert successful!";
    }
}


}

// Act on plugin de-activation
register_deactivation_hook(__FILE__, "deactivate_wp_sekolah");
function deactivate_wp_sekolah()
{
    delete_db_alumni();
    delete_db_calon();
    delete_db_pengaturan();
}

function delete_db_alumni()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'alumni_siswa';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}

function delete_db_calon()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'calon_siswa';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}

function delete_db_pengaturan()
{
    global $table_prefix, $wpdb;
    $customerTable = $table_prefix . 'pengaturan';

    // Query - Delete Table
    $sql = "DROP TABLE IF EXISTS `$customerTable` ;";
    // Delete Table
    $wpdb->query($sql);
}

define('ADMINSEKOLAH_DIR', plugin_dir_path(__FILE__) . '/views/admin/');
define('LANDINGSEKOLAH_DIR', plugin_dir_path(__FILE__) . '/views/landing/');
include 'php/model.php';
include 'php/admin.php';
include 'php/landing.php';

// Hook untuk menyambungkan CSS dan JS di Backend
add_action('admin_enqueue_scripts', 'adminsekolah_script');
function adminsekolah_script() {
    wp_enqueue_style('bs_css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css');
    wp_enqueue_style('dt_css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
    wp_enqueue_style('dt_button_css', 'https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css');
    wp_enqueue_style('custom_css', plugins_url('/css/custom-min.css', __FILE__));

    wp_enqueue_script('bs_js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js', array(), null, true);
    wp_enqueue_script('fa_js', 'https://kit.fontawesome.com/c00efe6860.js', array(), null, true);
    wp_enqueue_script('dt_js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_button_js', 'https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_zip_js', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_font_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array(), null, true);
    wp_enqueue_script('dt_button_html_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_print_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js', array('jquery'), null, true);

    wp_enqueue_script('custom_js', plugins_url('/js/custom-min.js', __FILE__), array(), null, true);
}

// Hook untuk menyambungkan CSS dan JS di Frontend
add_action('wp_enqueue_scripts', 'landingsekolah_script');
function landingsekolah_script() {
    wp_enqueue_style('bs_css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css');
    wp_enqueue_style('dt_css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
    wp_enqueue_style('dt_button_css', 'https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css');
    wp_enqueue_style('custom_css', plugins_url('/css/custom-min.css', __FILE__));

    // Menonaktifkan skrip jQuery default WordPress
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.7.0.js', array(), null, true);
    
    wp_enqueue_script('bs_js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js', array(), null, true);
    wp_enqueue_script('fa_js', 'https://kit.fontawesome.com/c00efe6860.js', array(), null, true);
    wp_enqueue_script('dt_js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_button_js', 'https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_zip_js', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array(), null, true);
    wp_enqueue_script('dt_pdf_font_js', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array(), null, true);
    wp_enqueue_script('dt_button_html_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js', array('jquery'), null, true);
    wp_enqueue_script('dt_print_js', 'https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js', array('jquery'), null, true);

    wp_enqueue_script('custom_js', plugins_url('/js/custom-min.js', __FILE__), array(), null, true);
}
