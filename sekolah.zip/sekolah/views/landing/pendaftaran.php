<div class="container-fluid pt-3">
    <h1 class="mb-4 text-success text-center fw-bold">
        <?php if (isset($pesan)) {
            echo $pesan;
        } ?>

        <?php
        
        $ambilPengaturan = ambilPengaturan('pengaturan', '12345');
        
        ?>
    </h1>
    <div class="row">
        <div class="col-12 col-md-7 mb-4">
            <h2 class="text-center">Selamat Datang Di Halaman Registrasi Pendaftaran Siswa Baru <?php echo $ambilPengaturan->nama_sekolah ?></h2>
            <div class="card mt-3 p-2 shadow-sm">
                <div class="alert alert-info" role="alert">
                    <h5 class="alert-heading">Langkah-langkah Pendaftaran</h5>
                    <pre class="bg-light p-3 rounded" style="border-left: 4px solid #007bff; white-space: pre-line;">
            1. Isi semua yang diminta
            2. File dokumen harus PDF maksimal 2 MB
            3. Gambar harus format JPG atau PNG 
            4. Setelah berhasil melakukan pendaftaran, harap cetak kartu 
            5. Jika tidak tersedia kartu, menandakan pendaftaran Anda belum berhasil 
            <?php echo $ambilPengaturan->pengumuman ?>
        </pre>
                    <a class="btn btn-primary me-2 mb-2" href="<?php echo $ambilPengaturan->url_cetak ?>">Cetak Kartu</a>
                    <a class="btn btn-primary mb-2" href="<?php echo $ambilPengaturan->url_pengumuman ?>">Pengumuman</a>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-5">
            <div class="card p-4 shadow-sm">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="nama_calon" class="form-label">Nama</label>
                        <?php wp_nonce_field('pendaftaran_nonce_action', 'pendaftaran_nonce'); ?>
                        <input type="text" class="form-control" name="nama_calon" id="nama_calon" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat_calon" class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat_calon" id="alamat_calon" required>
                    </div>
                    <div class="mb-3">
                        <label for="alumni_calon" class="form-label">Alumni Sekolah</label>
                        <input type="text" class="form-control" name="alumni_calon" id="alumni_calon" required>
                    </div>
                    <div class="mb-3">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" class="form-label" required>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="telepon" class="form-label">Telepon</label>
                        <input type="text" class="form-control" name="telepon" id="telepon" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="pasphoto" class="form-label">Pas Photo</label>
                        <input type="file" class="form-control" name="pasphoto" id="pasphoto" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <label for="dokumen_lainnya" class="form-label">Dokumen Lainnya</label>
                        <input type="file" class="form-control" name="dokumen_lainnya" id="dokumen_lainnya">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">