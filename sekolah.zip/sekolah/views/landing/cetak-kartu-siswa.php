<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Inisialisasi Dompdf
$options = new Options();
$options->set('defaultFont', 'Arial');
$options->set('isHtml5ParserEnabled', true);
$options->set('isPhpEnabled', true);

$dompdf = new Dompdf($options);

$data_siswa = ambilSiswaTelp('calon_siswa', $_POST['nomor_telepon']);

if ($data_siswa == null) {
    echo "
    <h1 style='
        color: red;
        font-size: 2rem; /* Ukuran font responsif */
        background-color: #ffe6e6;
        padding: 20px;
        border: 2px solid red;
        text-align: center;
        margin: 20px auto; /* Tengah secara otomatis */
        border-radius: 5px;
        max-width: 90%; /* Lebar maksimum untuk menjaga responsif */
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Tambahkan bayangan untuk kedalaman */
    '>
        Maaf, data tidak tersedia silahkan registrasi pendaftaran
    </h1>";
    exit();
}



$foto_path = 'http://localhost/custom/wp-content/plugins/sekolah/php/pasphoto/' . $data_siswa->pasphoto;


// Buat HTML untuk kartu pendaftaran siswa
$html = '<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Pendaftaran Siswa</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            width: 100%; /* Full width */
            max-width: 600px; /* Maximum width */
            margin: 0 auto;
            border: 1px solid #343a40;
            border-radius: 10px;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .photo {
            width: 100%;
            height: auto;
            border-radius: 5px;
            border: 2px solid #343a40;
            margin-bottom: 20px;
        }
        h1 {
            font-size: 28px;
            color: #343a40;
            margin-bottom: 20px;
        }
        .card-title {
            font-size: 22px;
            color: #343a40;
            margin-bottom: 15px;
        }
        .card-text {
            font-size: 16px;
            color: #555;
        }
        .card-text strong {
            color: #343a40;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Kartu Pendaftaran Siswa</h1>
        
        <div class="card">
            <img src="' . $foto_path . '"  alt="Pas Photo" class="photo"> 
            <h5 class="card-title">Nama: ' . $data_siswa->nama_calon . '</h5>
            <p class="card-text"><strong>Alamat:</strong> ' . $data_siswa->alamat_calon . '</p>
            <p class="card-text"><strong>Alumni Sekolah:</strong> ' . $data_siswa->alumni_calon . '</p>
            <p class="card-text"><strong>Telepon:</strong> ' . $data_siswa->telepon . '</p>
            <p class="card-text"><strong>Email:</strong> ' . $data_siswa->email . '</p>
            <p class="card-text"><strong>Jenis Kelamin:</strong> ' . $data_siswa->jenis_kelamin . '</p>
        </div>
    </div>
</body>
</html>';

// Set ukuran kertas dan orientasi
$dompdf->setPaper('A4', 'portrait');

// Load HTML ke dalam Dompdf
$dompdf->loadHtml($html);

// Render PDF
$dompdf->render();

// Kirim PDF ke browser
$dompdf->stream('kartu_pendaftaran_siswa.pdf', array('Attachment' => 0));
exit;
