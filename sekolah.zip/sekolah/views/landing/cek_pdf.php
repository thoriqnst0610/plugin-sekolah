<?php

require_once __DIR__. '/../admin/ambil_dokumen.php';
