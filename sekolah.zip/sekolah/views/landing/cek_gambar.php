<?php

require_once __DIR__. '/../admin/ambil_gambar.php';
