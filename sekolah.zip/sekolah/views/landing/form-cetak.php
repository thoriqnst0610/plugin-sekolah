<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Kartu Pendaftaran</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh; /* Mengatur tinggi body agar memenuhi viewport */
        }
        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%; /* Mengatur tinggi container agar memenuhi body */
        }
        .card {
            width: 100%; /* Full width */
            max-width: 500px; /* Maksimal lebar card */
        }
    </style>
</head>
<body>
    <div class="container centered-container">
        <div class="card shadow">
            <div class="card-body">
                <h1 class="mt-2 mb-4 text-center">Cetak Kartu Pendaftaran</h1>
                <form action="" method="POST">
                    <div class="mb-4">
                        <label for="nomor_telepon" class="form-label">Nomor Telepon</label>
                        <input type="text" class="form-control" name="nomor_telepon" id="nomor_telepon" placeholder="Masukkan nomor telepon" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">Cetak Kartu Pendaftaran</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
