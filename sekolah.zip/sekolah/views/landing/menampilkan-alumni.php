<div class="container-fluid pt-4">
    <h1 class="text-center mb-4">Daftar Alumni Siswa</h1>
    <div class="row">
        <!-- Alumni Card 1 66fb7b3b65cb3-admin.PNG-->
        <?php
        $no = 1;
        $ambilAlumni = ambilAlumni('alumni_siswa');
        foreach ($ambilAlumni as $data) { ?>

            <div class="col-12 col-sm-6 col-md-3">
                <div class="mt-2 card alumni-card text-center">
                    <img src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $data->foto_alumni; ?>" class="card-img-top img-fluid" alt="Alumni 1" style="height: 350px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?= $data->nama_alumni; ?></h5>
                        <p class="card-text">Tahun Lulus: <?= $data->tahun_lulus ?></p>
                        <p class="card-text">Jenis Kelamin: <?= $data->jenis_kelamin; ?></p>
                        <p class="card-text">Telepon: <?= $data->telepon; ?></p>
                    </div>
                </div>
            </div>

        <?php }  ?>
    </div>
</div>