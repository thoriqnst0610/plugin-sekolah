<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

        $options = new Options();
        $options->set('defaultFont', 'Arial');
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);

        $dompdf = new Dompdf($options);

        // Buat HTML untuk tabel
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Data Alumni</title>
            <style>
                .table { width: 100%; border-collapse: collapse; }
                .table th, .table td { border: 1px solid #000; padding: 8px; text-align: left; }
                .bg-dark { background-color: #343a40; color: white; }
            </style>
        </head>
        <body>
            <h1>Data Alumni</h1>
            <table class="table" id="alumni">
                <thead class="bg-dark">
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Jurusan</th>
                        <th>Alamat</th>
                        <th>Jenis Kelamin</th>
                        <th>Telepon</th>
                        <th>Cita-Cita</th>
                    </tr>
                </thead>
                <tbody>';

        $no = 1;
        $ambilAlumni = ambilAlumni('alumni_siswa');
        foreach ($ambilAlumni as $data) {
            $html .= '<tr>
                        <td>' . $no++ . '.</td>
                        <td>' . $data->nama_alumni . '</td>
                        <td>' . $data->jurusan . '</td>
                        <td>' . $data->alamat . '</td>
                        <td>' . $data->jenis_kelamin . '</td>
                        <td>' . $data->telepon . '</td>
                        <td>' . $data->cita_cita . '</td>
                      </tr>';
        }

        $html .= '</tbody></table></body></html>';

        // Set paper size and orientation
        $dompdf->setPaper('A4', 'portrait');

        // Load HTML into Dompdf
        $dompdf->loadHtml($html);

        // Render the PDF
        $dompdf->render();

        // Send the PDF to the browser
        $dompdf->stream('data_alumni.pdf', array('Attachment' => 0));
        exit;
    
