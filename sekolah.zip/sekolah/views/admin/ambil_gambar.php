<?php

// Mengambil parameter gambar dengan sanitasi
$gambar = $_GET['pasphoto'];


// Tentukan path ke file gambar
$file = __DIR__ . '/../../php/pasphoto/' . $gambar;

// Cek apakah file ada
if (file_exists($file)) {
    // Set header yang sesuai untuk jenis gambar
    if (pathinfo($file, PATHINFO_EXTENSION) === 'png') {
        header('Content-Type: image/png'); // Set header untuk PNG
    } else {
        header('Content-Type: image/jpg'); // Set header untuk JPG
    }
    
    header('Content-Disposition: inline; filename="' . basename($file) . '"');
    readfile($file);
    exit; // Hentikan eksekusi setelah mengirimkan file
} else {
    // Jika file tidak ditemukan, kirimkan header 404
    header('HTTP/1.0 404 Not Found');
    echo 'File not found.';
}