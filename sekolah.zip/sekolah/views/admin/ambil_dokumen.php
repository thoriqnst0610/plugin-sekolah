<?php

$dokumen = isset($_GET['dokumen']) ? basename($_GET['dokumen']) : '';

$file = __DIR__ . '/../../php/dokumenlainnya/' . $dokumen;

if (file_exists($file)) {
    header('Content-type: application/pdf');
    header('Content-Disposition: inline; filename="' . basename($file) . '"');
    readfile($file);
} else {
    echo 'File not found.';
}