<div class="container-fluid pt-3">
    <div class="d-flex align-items-center justify-content-between border-bottom border-dark mb-3 pb-1">
        <h3>Pengaturan</h3>
        <a href="<?= admin_url('admin.php?page=menampilkan_alumni'); ?>" class="btn btn-secondary"><i class="fa fa-reply"></i> Kembali</a>
    </div>

    <!-- Mulai-Notifikasi -->
     <!-- Mulai-Notifikasi -->
     <?php if (isset($notifikasi)) { ?>
        <div class="bg bg-warning text-black p-3 mb-3 rounded text-center"><?php if (isset($notifikasi)) echo $notifikasi; ?></div>
    <?php } ?>
    <!-- Selesai-Notifikasi -->
    <div class="row align-items-center justify-content-center">
        <div class="card col-8">
            <div class="card-body">
                <form action="" method="POST">
                    <?php $ambilPengaturan = ambilPengaturan('pengaturan', '12345');?>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Nama Sekolah</label>
                        <input class="col-8 p-6 form-control" type="text" name="nama_sekolah" value="<?php echo $ambilPengaturan->nama_sekolah ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Informasi Pendaftaran</label>
                        <input class="col-8 p-6 form-control" type="text" name="pengumuman" value="<?php echo $ambilPengaturan->pengumuman ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Link Cetak Kartu</label>
                        <input class="col-8 p-6 form-control" type="text" name="url_cetak" value="<?php echo $ambilPengaturan->url_cetak ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Link pengumuman</label>
                        <input class="col-8 p-6 form-control" type="text" name="url_pengumuman" value="<?php echo $ambilPengaturan->url_pengumuman ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Link menampilkan gambar&pdf</label>
                        <input class="col-8 p-6 form-control" type="text" name="url_gambar_pdf" value="<?php echo $ambilPengaturan->url_gambar_pdf ?>">
                    </div>
                    <button type="submit" class="float-right btn btn-primary">Simpan</button>
                </form>
            </div>

        </div>
    </div>
</div>
</div>