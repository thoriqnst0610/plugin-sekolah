<div class="container-fluid pt-3">
    <div class="d-flex align-items-center justify-content-between border-bottom border-dark mb-3 pb-1">
        <h3>Ubah Data</h3>
        <a href="<?= admin_url('admin.php?page=menampilkan_alumni'); ?>" class="btn btn-secondary"><i class="fa fa-reply"></i> Kembali</a>
    </div>

    <!-- Mulai-Notifikasi -->
     <!-- Mulai-Notifikasi -->
     <?php if (isset($notifikasi)) { ?>
        <div class="bg bg-warning text-black p-3 mb-3 rounded text-center"><?php if (isset($notifikasi)) echo $notifikasi; ?></div>
    <?php } ?>
    <!-- Selesai-Notifikasi -->
    <div class="row align-items-center justify-content-center">
        <div class="card col-8">
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <?php $ambilAlumniId = ambilAlumniId('alumni_siswa', $_GET['id_alumni']);?>
                    <div class="form-group row d-none">
                        <label class="col-4 col-form-label">ID Alumni</label>
                        <?php wp_nonce_field('alumniedit_nonce_action', 'alumniedit_nonce'); ?>
                        <input class="col-8 form-control" type="text" name="id_alumni" value="<?= $ambilAlumniId->id_alumni; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Nama ALumni</label>
                        <input class="col-8 form-control" type="text" name="nama_alumni" value="<?= $ambilAlumniId->nama_alumni; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Alamat</label>
                        <input class="col-8 form-control" type="text" name="alamat" value="<?= $ambilAlumniId->alamat; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Jurusan</label>
                        <input class="col-8 form-control" type="text" name="jurusan" value="<?= $ambilAlumniId->jurusan; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Jurusan</label>
                        <input class="col-8 form-control" type="text" name="telepon" value="<?= $ambilAlumniId->telepon; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Jenis Kelamin</label>
                        <input class="col-8 form-control" type="text" name="jenis_kelamin" value="<?= $ambilAlumniId->jenis_kelamin; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Cita cita</label>
                        <input class="col-8 form-control" type="text" name="cita_cita" value="<?= $ambilAlumniId->cita_cita; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Tahun Lulus</label>
                        <input class="col-8 form-control" type="text" name="tahun_lulus" value="<?= $ambilAlumniId->tahun_lulus; ?>">
                    </div>
                    <div class="form-group row">
                        <label class="col-4 col-form-label">Foto Alumni</label>
                        <input class="col-8 form-control" type="hidden" name="foto_alumni" value="<?= $ambilAlumniId->foto_alumni; ?>">
                        <input class="col-8 form-control " type="file" name="photo">
                    </div>
                    <button type="submit" class="float-right btn btn-primary">Simpan</button>
                </form>
            </div>

        </div>
    </div>
</div>
</div>