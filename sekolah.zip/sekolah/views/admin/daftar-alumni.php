<?php

$ambilPengaturan = ambilPengaturan('pengaturan', '12345');


?>
<div class="container-fluid pt-3">
    <div class="d-flex align-items-center justify-content-between border-bottom border-dark mb-3 pb-1">
        <h3>Data Alumni Sekolah</h3>
        <div class="ml-auto"> <!-- Aligns the buttons to the right -->
            <button data-toggle="modal" data-target="#tambahModal" class="btn btn-primary">Tambah Alumni</button>
            <a class="btn btn-secondary" href="<?= $ambilPengaturan->url_gambar_pdf ?>pdf/?generate_pdf=alumni_siswa">Ekspor Pdf</a>
        </div>
    </div>

    <!-- Mulai-Modal Form Tambah -->
    <div class="modal fade mt-5" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="tambahModalLabel">Tambah Data Alumni</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Nama Alumni</label>
                            <?php wp_nonce_field('alumnitambah_nonce_action', 'alumnitambah_nonce'); ?>
                            <input class="col-9 form-control" type="text" name="nama_alumni" placeholder="Masukkan Nama">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Alamat</label>
                            <input class="col-9 form-control" type="text" name="alamat" placeholder="Masukkan Alamat">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Jenis Kelamin</label>
                            <select id="jenis_kelamin" name="jenis_kelamin" class="form-select" required>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Jurusan</label>
                            <input class="col-9 form-control" type="text" name="jurusan" placeholder="Masukkan Jurusan">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Telepon</label>
                            <input class="col-9 form-control" type="" name="telepon" placeholder="Masukkan Telepon">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Cita-cita</label>
                            <input class="col-9 form-control" type="text" name="cita_cita" placeholder="Masukkan Cita-cita">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Tahun Lulus</label>
                            <input class="col-9 form-control" type="text" name="tahun_lulus" placeholder="Masukkan Cita-cita">
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">File Photo</label>
                            <input class="col-9 form-control" type="file" name="photo" placeholder="File Foto">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- Selesai-Modal Form Tambah -->

    <!-- Mulai-Notifikasi -->
    <?php if (isset($notifikasi)) { ?>
        <div class="bg bg-warning text-black p-3 mb-3 rounded text-center"><?php if (isset($notifikasi)) echo $notifikasi; ?></div>
    <?php } ?>


    <!-- Selesai-Notifikasi -->

    <!-- Mulai-Tabel tampil data -->
    <table class="table" id="alumni">
        <thead class="bg-dark text-white">
            <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Jurusan</th>
                <th>Alamat</th>
                <th>Jenis Kelamin</th>
                <th>Telepon</th>
                <th>Cita-Cita</th>
                <th>Lulus</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $ambilAlumni = ambilAlumni('alumni_siswa');
            foreach ($ambilAlumni as $data) {

                $id_alumni = $data->id_alumni;
                $tampilALumniId = tampilAlumniId('alumni_siswa', $data->id_alumni);
            ?>
                <tr>
                    <td><?= $no++; ?>.</td>
                    <td><?= $data->nama_alumni; ?></td>
                    <td><?= $data->jurusan; ?></td>
                    <td><?= $data->alamat; ?></td>
                    <td><?= $data->jenis_kelamin; ?></td>
                    <td><?= $data->telepon; ?></td>
                    <td><?= $data->cita_cita; ?></td>
                    <td><?= $data->tahun_lulus; ?></td>
                    <td>
                    <img class="img-fluid" style="width: 100px;" src="<?php echo plugin_dir_url(__FILE__) . '../../gambar_alumni/' . $data->foto_alumni; ?>" alt="Gambar" />

                    </td>
                    <td>
                        <a href="<?= admin_url('admin.php?page=mengedit_alumni') . '&id_alumni=' . $id_alumni; ?>" class="btn btn-warning text-white mb-1"><i class="fa fa-edit"></i> Ubah</a>
                        <button data-toggle="modal" data-target="#hapusModal<?= $id_alumni; ?>" class="btn btn-danger mb-1"><i class="fa fa-trash"></i> Hapus</button>
                    </td>
                </tr>

                <!-- Mulai-Modal Form Hapus -->
                <div class="modal fade mt-5" id="hapusModal<?= $id_alumni; ?>" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
                    <form action="" method="POST">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="hapusModalLabel">Hapus Data</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body mx-5">
                                    <input hidden type="text" name="aksi" value="hapus">
                                    <input hidden type="text" name="id_alumni" value="<?= $tampilALumniId->id_alumni; ?>">
                                    <div class="form-group row justify-content-between">
                                        <label class="col-4 col-form-label">Nama</label>
                                        <label class="col-6 col-form-label text-right"><span class="badge badge-primary"><?= $tampilALumniId->nama_alumni; ?></span></label>
                                    </div>
                                    <div class="form-group row justify-content-between">
                                        <label class="col-4 col-form-label">Alamat</label>
                                        <label class="col-6 col-form-label text-right"><span class="badge badge-primary"><?= $tampilALumniId->alamat; ?></span></label>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Selesai-Modal Form Hapus -->
            <?php } ?>
        </tbody>
    </table>
    <!-- Selesai-Tabel tampil data -->
</div>