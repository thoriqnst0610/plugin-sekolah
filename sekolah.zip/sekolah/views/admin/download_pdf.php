

<iframe src="ambil_dokumen.php" width="600" height="800"></iframe>