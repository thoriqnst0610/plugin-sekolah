<div class="container-fluid pt-3">
<?php

$ambilPengaturan = ambilPengaturan('pengaturan', '12345');

?>

    <div class="d-flex align-items-center justify-content-between border-bottom border-dark mb-3 pb-1">
        <h3>Data Pendaftar Siswa</h3>
        <div class="ml-auto">
            <button class="btn btn-primary" data-toggle="modal" data-target="#hapusSemuaSiswa">Hapus Keseluruhan</button>
            <a class="btn btn-secondary" href="<?= $ambilPengaturan->url_gambar_pdf ?>pdf/?generate_pdf=calon_siswa">Ekspor Pdf</a>

        </div>
    </div>

    <!-- Mulai-Notifikasi -->
    <?php if (isset($notifikasi)) { ?>
        <div class="bg bg-warning text-black p-3 mb-3 rounded text-center"><?php if (isset($notifikasi)) echo $notifikasi; ?></div>
    <?php } ?>
    <!-- Selesai-Notifikasi -->

    <!-- Mulai-Tabel tampil data -->
    <table class="table" id="Siswa">
        <thead class="bg-dark text-white">
            <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Alumni</th>
                <th>Jenis Kelamin</th>
                <th>Telepon</th>
                <th>Email</th>
                <th>Pasphoto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $ambilSiswa = ambilSiswa('calon_siswa');
            foreach ($ambilSiswa as $data) {

                $id_calon = $data->id_calon;
                $tampilDataId = ambilSiswaId('calon_siswa', $id_calon);
            ?>
                <tr>
                    <td><?= $no++; ?>.</td>
                    <td><?= $data->nama_calon; ?></td>
                    <td><?= $data->alamat_calon; ?></td>
                    <td><?= $data->alumni_calon; ?></td>
                    <td><?= $data->jenis_kelamin; ?></td>
                    <td><?= $data->telepon; ?></td>
                    <td><?= $data->email; ?></td>
                    <td>
                        <a href="<?= $ambilPengaturan->url_gambar_pdf ?>pdf/?pasphoto=<?= $data->pasphoto ?>">lihat gambar</a>
                    </td>
                    <td>
                        <a href="<?= $ambilPengaturan->url_gambar_pdf ?>pdf/?dokumen=<?= $data->dokumen_lainnya ?>" target="_blank" class="btn btn-warning text-white mb-1"><i class="fa fa-edit"></i>Dokumen</a>
                        <button data-toggle="modal" data-target="#hapusModal<?= $id_calon; ?>" class="btn btn-danger mb-1"><i class="fa fa-trash"></i> Hapus</button>
                    </td>
                </tr>

                <!-- Mulai-Modal Form Hapus -->
                <div class="modal fade mt-5" id="hapusModal<?= $id_calon; ?>" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
                    <form action="" method="POST">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="hapusModalLabel">Hapus Data</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body mx-5">
                                    <input hidden type="text" name="aksi" value="hapus">
                                    <input hidden type="text" name="id_calon" value="<?= $tampilDataId->id_calon; ?>">
                                    <div class="form-group row justify-content-between">
                                        <label class="col-4 col-form-label">Nama</label>
                                        <label class="col-6 col-form-label text-right"><span class="badge badge-primary"><?= $tampilDataId->nama_calon; ?></span></label>
                                    </div>
                                    <div class="form-group row justify-content-between">
                                        <label class="col-4 col-form-label">Alamat</label>
                                        <label class="col-6 col-form-label text-right"><span class="badge badge-primary"><?= $tampilDataId->alamat_calon; ?></span></label>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            <?php } ?>
        </tbody>
    </table>
    <!-- Selesai-Tabel tampil data -->

    <!-- Hapus Seluruh Data -->
    <div class="modal fade mt-5" id="hapusSemuaSiswa" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
        <form action="" method="POST">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="hapusModalLabel">Hapus Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <input hidden type="text" name="aksi" value="hapus_keseluruhan">
                    <div class="modal-body mx-5">
                        <h3 class="text-success fw-bold">Apakah Anda Yakin Akan Menghapus Keseluruhan Data?</h3>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Hapus</button>
                    </div>
                </div>
            </div>
        </form>
    </div>




</div>